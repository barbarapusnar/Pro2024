﻿namespace DatotečniSistem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtVnos = new System.Windows.Forms.TextBox();
            this.btnPrikaži = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMapa = new System.Windows.Forms.TextBox();
            this.btnGor = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lstDat = new System.Windows.Forms.ListBox();
            this.lstMape = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vnesi ime mape in klikni Prikaži";
            // 
            // txtVnos
            // 
            this.txtVnos.Location = new System.Drawing.Point(18, 61);
            this.txtVnos.Name = "txtVnos";
            this.txtVnos.Size = new System.Drawing.Size(304, 31);
            this.txtVnos.TabIndex = 1;
            // 
            // btnPrikaži
            // 
            this.btnPrikaži.Location = new System.Drawing.Point(391, 61);
            this.btnPrikaži.Name = "btnPrikaži";
            this.btnPrikaži.Size = new System.Drawing.Size(120, 31);
            this.btnPrikaži.TabIndex = 2;
            this.btnPrikaži.Text = "Prikaži";
            this.btnPrikaži.UseVisualStyleBackColor = true;
            this.btnPrikaži.Click += new System.EventHandler(this.btnPrikaži_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstMape);
            this.groupBox1.Controls.Add(this.lstDat);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnGor);
            this.groupBox1.Controls.Add(this.txtMapa);
            this.groupBox1.Location = new System.Drawing.Point(18, 124);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(574, 925);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vsebina mape";
            // 
            // txtMapa
            // 
            this.txtMapa.Location = new System.Drawing.Point(19, 31);
            this.txtMapa.Name = "txtMapa";
            this.txtMapa.ReadOnly = true;
            this.txtMapa.Size = new System.Drawing.Size(341, 31);
            this.txtMapa.TabIndex = 0;
            // 
            // btnGor
            // 
            this.btnGor.Location = new System.Drawing.Point(422, 31);
            this.btnGor.Name = "btnGor";
            this.btnGor.Size = new System.Drawing.Size(92, 31);
            this.btnGor.TabIndex = 1;
            this.btnGor.Text = "Gor";
            this.btnGor.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Datoteke";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(294, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Mape";
            // 
            // lstDat
            // 
            this.lstDat.FormattingEnabled = true;
            this.lstDat.ItemHeight = 25;
            this.lstDat.Location = new System.Drawing.Point(24, 127);
            this.lstDat.Name = "lstDat";
            this.lstDat.Size = new System.Drawing.Size(209, 329);
            this.lstDat.TabIndex = 4;
            // 
            // lstMape
            // 
            this.lstMape.FormattingEnabled = true;
            this.lstMape.ItemHeight = 25;
            this.lstMape.Location = new System.Drawing.Point(299, 127);
            this.lstMape.Name = "lstMape";
            this.lstMape.Size = new System.Drawing.Size(209, 329);
            this.lstMape.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 1061);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnPrikaži);
            this.Controls.Add(this.txtVnos);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtVnos;
        private System.Windows.Forms.Button btnPrikaži;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lstMape;
        private System.Windows.Forms.ListBox lstDat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGor;
        private System.Windows.Forms.TextBox txtMapa;
    }
}

