﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DatotečniSistem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPrikaži_Click(object sender, EventArgs e)
        {
            string pot = txtVnos.Text;
            DirectoryInfo mapa = new DirectoryInfo(pot);
            if (mapa.Exists)
            {
                IzpišiVsebino(mapa.FullName);
                return;
            }
            //kaj pa, če je uporabnik vnesel datoteko
            FileInfo f = new FileInfo(pot);
            if (f.Exists)
            {
                IzpišiVsebino(f.Directory.FullName);
                return;
            }
            throw new Exception("Ni ne datoteke ne mape s tem imenom");
        }
        private void Počisti()
        {
            lstDat.Items.Clear();
            lstMape.Items.Clear();
            txtMapa.Clear();
        }
        private void IzpišiVsebino(string fullName)
        {
            Počisti();
            DirectoryInfo d = new DirectoryInfo(fullName);
            txtMapa.Text = d.FullName;
            foreach (DirectoryInfo d1 in d.GetDirectories())
            {
                lstMape.Items.Add(d1.Name);
            }
            foreach (FileInfo f in d.GetFiles())
            {
                lstDat.Items.Add(f.Name);
            }
        }
    }
}
